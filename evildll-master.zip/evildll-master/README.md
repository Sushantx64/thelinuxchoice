# EvilDLL v1.0
## Author: github.com/thelinuxchoice
## Twitter: twitter.com/linux_choice
### Read the license before using any part from this code :) 

Malicious DLL (Win Reverse Shell) generator for DLL Hijacking

![f1](https://user-images.githubusercontent.com/34893261/78950022-d9c44d00-7aa3-11ea-9ae3-e26f667fede3.jpg)
![f2](https://user-images.githubusercontent.com/34893261/78950029-e052c480-7aa3-11ea-844c-667347ba29f7.jpg)

### Features:
#### Reverse TCP Port Forwarding using Ngrok.io
#### Custom Port Forwarding option (LHOST,LPORT)
#### Example of DLL Hijacking included (Half-Life Launcher file)
#### Tested on Win7 (7601), Windows 10

### Requirements:
#### Mingw-w64 compiler: apt-get install mingw-w64
#### Ngrok Authtoken (for TCP Tunneling): Sign up at: https://ngrok.com/signup
#### Your authtoken is available on your dashboard: https://dashboard.ngrok.com
#### Install your auhtoken: ./ngrok authtoken <YOUR_AUTHTOKEN>

## Legal disclaimer:

Usage of EvilDLL for attacking targets without prior mutual consent is illegal. It's the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program 

### Usage:
```
git clone https://github.com/thelinuxchoice/evildll
cd evildll
bash evildll.sh
```
### Donate!
Pay me a coffee:
### Paypal:
https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=CLKRT5QXXFJY4&source=url
