# Evilreg v1.0
## Author: github.com/thelinuxchoice
## Twitter: twitter.com/linux_choice
### Read the license before using any part from this code :) 

Reverse shell using Windows Registry file (.reg).

![re](https://user-images.githubusercontent.com/34893261/78690039-581ac680-78cd-11ea-87ad-5d7763fdbcdf.jpg)

### Features:
#### Reverse TCP Port Forwarding using Ngrok.io

### Requirements:
#### Ngrok Authtoken (for TCP Tunneling): Sign up at: https://ngrok.com/signup
#### Your authtoken is available on your dashboard: https://dashboard.ngrok.com
#### Install your auhtoken: ./ngrok authtoken <YOUR_AUTHTOKEN>
#### Target must reboot/re-login after installing the .reg file

## Legal disclaimer:

Usage of Evilreg for attacking targets without prior mutual consent is illegal. It's the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program 

### Usage:
```
git clone https://github.com/thelinuxchoice/evilreg
cd evilreg
bash evilreg.sh
```

### Donate!
Pay a coffee:
### Paypal:
https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=CLKRT5QXXFJY4&source=url

